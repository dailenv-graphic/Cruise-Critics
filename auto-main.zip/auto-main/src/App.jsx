import "./styles.css";
import "./tailwind.css";
import { Desktop } from "./Desktop/Desktop";

export default function App() {
  return (
    <div>
      <Desktop />
    </div>
  );
}
